"""入口:创建共享上下文 → 主 Agent 编排三个子 Agent → 打印轨迹与汇总报告。

用法:
    python main.py                      # 默认主题: 协作式团队晨会
    python main.py --topic "周会效率"    # 自定义主题
    python main.py --quiet               # 只输出最终汇总报告
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

from agentic import tools
from agentic.base import AgentContext
from agentic.coordinator import CoordinatorAgent
from agentic.llm import make_llm_client


def main() -> None:
    # Windows 控制台默认 GBK,改为 UTF-8 以支持轨迹中的符号
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
        sys.stderr.reconfigure(encoding="utf-8", errors="replace")
    except AttributeError:  # 极老版本无 reconfigure
        pass

    parser = argparse.ArgumentParser(description="多 Agent 协作编排系统演示")
    parser.add_argument("--topic", default="协作式团队晨会", help="主任务主题")
    parser.add_argument("--quiet", action="store_true", help="只输出最终报告,不打印轨迹")
    args = parser.parse_args()

    workdir = str(Path(__file__).resolve().parent)

    # LLM 模式:配置了 DEEPSEEK_API_KEY 自动启用;否则回退规则模式(离线可跑)
    llm = make_llm_client()
    if llm:
        print(f"[LLM] 已启用真实大模型: {llm.name} ({llm.model}),正在自检连通性...")
        try:
            llm.chat("你是助手", "只回复两个字: 正常")
            print("[LLM] 连通性自检通过 ✓")
        except Exception as e:
            print(f"[LLM] ✗ 自检失败: {e}")
            print("[LLM] 请按顺序排查:")
            print("      ① DEEPSEEK_API_KEY 是否完整正确(以 sk- 开头,无多余空格)")
            print("      ② 网络能否访问 api.deepseek.com(公司/校园网可能拦截)")
            print("      ③ DeepSeek 账户是否有余额/模型是否可用(deepseek-chat)")
            print("[LLM] 如需先用离线规则模式演示: 清空环境变量后重开终端 (setx DEEPSEEK_API_KEY \"\")")
            sys.exit(1)
    else:
        print("[LLM] 未检测到 DEEPSEEK_API_KEY,使用规则模式(不调用大模型)")

    ctx = AgentContext(workdir=workdir, tools=tools.register(workdir), llm=llm)

    coordinator = CoordinatorAgent(topic=args.topic)
    final_report = coordinator.run(ctx)

    if not args.quiet:
        print("=" * 64)
        print("【执行轨迹】三个子 Agent 各自的目标驱动循环")
        print("=" * 64)
        for line in ctx.trace_log:
            print(line)
        print()

    print("=" * 64)
    print("【最终汇总】由主 Agent 生成")
    print("=" * 64)
    print(final_report)
    print("\n完整报告已写入: output/final_report.md")


if __name__ == "__main__":
    main()
