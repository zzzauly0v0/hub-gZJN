"""LLM 适配器:把子 Agent 的能力从"规则"升级为"真实大模型"。

设计(零新依赖,用标准库 urllib 调 OpenAI 兼容协议):
- AgentContext.llm 为 None 时,子 Agent 走原有规则逻辑(离线可跑);
- 配置了环境变量 DEEPSEEK_API_KEY 后,make_llm_client() 返回 DeepSeekClient,
  子 Agent 自动切换为 LLM 分支,循环骨架(等待/轮次/汇总)完全不变。

环境变量:
    DEEPSEEK_API_KEY    必填,DeepSeek 平台申请的 key
    DEEPSEEK_MODEL      可选,默认 deepseek-chat
    DEEPSEEK_BASE_URL   可选,默认 https://api.deepseek.com/chat/completions
"""

from __future__ import annotations

import json
import os
import urllib.error
import urllib.request


class LLMClient:
    """LLM 客户端抽象:chat(system, user) -> str。"""

    name = "llm"

    def chat(self, system: str, user: str) -> str:
        raise NotImplementedError(f"{type(self).__name__} 必须实现 chat()")


class DeepSeekClient(LLMClient):
    """DeepSeek API 客户端(OpenAI 兼容协议)。"""

    name = "DeepSeek"

    def __init__(
        self,
        api_key: str | None = None,
        model: str | None = None,
        base_url: str | None = None,
        timeout: int = 20,
    ):
        self.api_key = api_key or os.environ.get("DEEPSEEK_API_KEY", "")
        self.model = model or os.environ.get("DEEPSEEK_MODEL", "deepseek-chat")
        self.base_url = base_url or os.environ.get(
            "DEEPSEEK_BASE_URL", "https://api.deepseek.com/chat/completions"
        )
        self.timeout = timeout

    def chat(self, system: str, user: str) -> str:
        if not self.api_key:
            raise RuntimeError("未配置 DEEPSEEK_API_KEY 环境变量")

        payload = {
            "model": self.model,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "temperature": 0.7,
        }
        req = urllib.request.Request(
            self.base_url,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={
                "Content-Type": "application/json",
                "Authorization": f"Bearer {self.api_key}",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                data = json.loads(resp.read().decode("utf-8"))
        except urllib.error.HTTPError as e:
            body = e.read().decode("utf-8", errors="replace")[:200]
            raise RuntimeError(f"DeepSeek API HTTP {e.code}: {body}") from e
        except urllib.error.URLError as e:
            raise RuntimeError(f"DeepSeek API 网络错误: {e.reason}") from e

        try:
            return data["choices"][0]["message"]["content"].strip()
        except (KeyError, IndexError, TypeError) as e:
            raise RuntimeError(f"DeepSeek API 响应格式异常: {data}") from e


def make_llm_client() -> LLMClient | None:
    """配置了 DEEPSEEK_API_KEY 则返回 DeepSeekClient,否则返回 None(规则模式)。"""
    if os.environ.get("DEEPSEEK_API_KEY"):
        return DeepSeekClient()
    return None
