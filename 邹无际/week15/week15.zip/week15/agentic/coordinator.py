"""主 Agent(编排者):拆解任务 → 并行下发三个子 Agent → 汇总产出。

汇总职责:
1. 接收一个总目标(topic);
2. 规划:拆成三个子任务,匹配到三个子 Agent;
3. 并行下发:三个子 Agent 各自运行自己的目标驱动循环;
4. 收集:等待全部子 Agent 返回,读取共享数据区;
5. 汇总:把三份子产出合成最终报告,写入 output/。
"""

from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor

from .base import Agent, AgentContext
from .subagents import CollectorAgent, ReviewerAgent, WriterAgent


class CoordinatorAgent(Agent):
    """主 Agent:编排三个子 Agent 协作,最后汇总结果。"""

    name = "主Agent"
    description = "拆解任务、并行下发子 Agent、汇总最终产出"

    def __init__(self, topic: str = "协作式团队晨会"):
        self.topic = topic
        self.sub_agents = [CollectorAgent(), WriterAgent(), ReviewerAgent()]

    # ------------------------------------------------------------------ #
    # 规划
    # ------------------------------------------------------------------ #
    def _plan(self) -> list[str]:
        """把总目标拆成三个可并行执行的子任务。"""
        return [
            f"[规划] 总目标: 产出一份关于「{self.topic}」的协作报告",
            f"[规划] 子任务1 → {self.sub_agents[0].name}: 收集事实(目标 ≥ 8 条,循环直到凑齐)",
            f"[规划] 子任务2 → {self.sub_agents[1].name}: 撰写初稿(目标: 自评 ≥ 80 分,循环修订)",
            f"[规划] 子任务3 → {self.sub_agents[2].name}: 审校修正(目标: 检查通过,循环审校)",
        ]

    # ------------------------------------------------------------------ #
    # 汇总
    # ------------------------------------------------------------------ #
    def _summarize(self, ctx: AgentContext) -> str:
        facts = ctx.data.get("facts", [])
        draft = ctx.data.get("draft", "")
        score = ctx.data.get("score", 0)
        reports = ctx.data.get("reports", {})

        lines = [
            f"# 《{self.topic}》协作产出报告",
            "",
            f"> 由主 Agent 汇总 {len(self.sub_agents)} 个子 Agent 的产出生成",
            "",
            "## 一、资料收集结果(收集者)",
            f"共 {len(facts)} 条事实:",
            *[f"- {f}" for f in facts],
            "",
            "## 二、成稿与质量(撰写者 → 审校者)",
            f"最终成稿 {len(draft)} 字,撰写者自评 {score}/100 分;审校者已按规则修正标点/重复字等问题。",
            "",
            draft.strip(),
            "",
            "## 三、各子 Agent 汇报",
            *[f"- **{name}**: {summary}" for name, summary in reports.items()],
            "",
            "## 四、子 Agent 通信消息(消息总线)",
            *[f"- {m.content}" for m in ctx.messages],
        ]
        return "\n".join(lines)

    # ------------------------------------------------------------------ #
    # 编排主流程
    # ------------------------------------------------------------------ #
    def run(self, ctx: AgentContext) -> str:
        ctx.data["topic"] = self.topic  # 供子 Agent(撰写者等)使用
        ctx.trace(f"▶ 主 Agent 开始执行,目标: 「{self.topic}」")
        for line in self._plan():
            ctx.trace(line)

        # -- 并行下发:三个子 Agent 各自跑自己的 loop,共享同一 ctx -- #
        with ThreadPoolExecutor(max_workers=len(self.sub_agents)) as pool:
            futures = {pool.submit(a.run, ctx): a for a in self.sub_agents}
            results = {}
            for fut, agent in futures.items():
                results[agent.name] = fut.result()  # 等待全部完成

        # -- 收集与汇总 -- #
        final_report = self._summarize(ctx)
        out_rel = "output/final_report.md"
        ctx.tool("write_file", out_rel, final_report)
        ctx.trace(
            f"◼ 主 Agent 结束: 汇总完成,收到 {len(ctx.messages)} 条子 Agent 消息,"
            f"报告已写入 {out_rel}"
        )
        return final_report
