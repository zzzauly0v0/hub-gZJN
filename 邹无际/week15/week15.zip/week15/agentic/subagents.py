"""三个子 Agent:资料收集者、初稿撰写者、质量审校者。

每个子 Agent 内部持有一个 AgentLoop(目标驱动循环):
- CollectorLoop : 每轮抓一篇资料并抽取事实,直到凑齐 MIN_FACTS 条;
- WriterLoop    : 每轮写作/修订初稿并自评打分,直到分数达标;
- ReviewerLoop  : 轮询等待初稿 → 审校 → 修正 → 再审校,直到检查通过。

三个 loop 由主 Agent 并行下发,通过共享的 AgentContext.data 协作。
"""

from __future__ import annotations

import re

from .base import Agent, AgentContext, AgentLoop, LoopStatus

# 目标:收集的事实条数
MIN_FACTS = 8
# 目标:初稿自评分
SCORE_TARGET = 80


# =========================================================================== #
# Agent A —— 资料收集者
# =========================================================================== #
class CollectorLoop(AgentLoop):
    """目标驱动循环:抓取 → 抽取事实 → 判断是否凑齐。"""

    def __init__(self, max_rounds: int = 6):
        super().__init__("收集循环", max_rounds)
        self.cursor = 0  # 已抓取的资料序号

    @staticmethod
    def _extract_facts(article: str, max_per_article: int = 3) -> list[str]:
        """按句号切句,过滤短句与错误信息,返回"事实"候选。"""
        sentences = [s.strip() for s in re.split(r"[。！？]", article) if s.strip()]
        facts = []
        for s in sentences:
            if len(s) < 8 or s.startswith("[错误]") or s.startswith("[资料:"):
                continue
            if "。" in s or "、" in s or len(s) >= 12:  # 含信息量的句子
                facts.append(s)
            if len(facts) >= max_per_article:
                break
        return facts

    def _extract_facts_llm(
        self, ctx: AgentContext, article: str, max_per_article: int = 3
    ) -> list[str]:
        """LLM 抽取:让大模型理解资料并提炼事实(失败或结果过短时退回规则)。"""
        try:
            text = ctx.llm.chat(
                "你是资料分析助手,只从资料中抽取客观事实,不做总结和评论。",
                (
                    f"从下面的资料中抽取最多 {max_per_article} 条独立事实。\n"
                    f"要求:每条一行,只输出事实本身,不要编号、不要列表符号、不要解释。\n\n"
                    f"资料:\n{article}"
                ),
            )
        except Exception as e:
            ctx.trace(f"  [LLM 抽取失败,退回规则] {e}")
            return self._extract_facts(article)
        facts = []
        for line in text.splitlines():
            line = re.sub(r"^[\s\-*•\d.、]+", "", line).strip()  # 去掉行首符号/序号
            if line and len(line) >= 8 and not line.lower().startswith(("ok", "好的", "以下")):
                facts.append(line)
            if len(facts) >= max_per_article:
                break
        if not facts:  # LLM 输出过短/为空,规则兜底
            ctx.trace("  [LLM 抽取结果过短,退回规则]")
            return self._extract_facts(article)
        return facts

    def step(self, ctx: AgentContext) -> LoopStatus:
        article = ctx.tool("fetch_article", index=self.cursor)
        self.cursor += 1
        if article.startswith("[错误]"):  # 来源耗尽
            ctx.trace(f"  来源耗尽({self.cursor} 篇),未能凑齐 {MIN_FACTS} 条")
            return LoopStatus.EXHAUSTED

        if ctx.llm:
            new_facts = self._extract_facts_llm(ctx, article)
        else:
            new_facts = self._extract_facts(article)
        facts = ctx.data.setdefault("facts", [])
        # 简单去重
        for f in new_facts:
            if f not in facts:
                facts.append(f)
        ctx.trace(
            f"  抓取资料#{self.cursor}: 提取 {len(new_facts)} 条,"
            f"累计 {len(facts)}/{MIN_FACTS}"
        )
        return LoopStatus.DONE if len(facts) >= MIN_FACTS else LoopStatus.CONTINUE


class CollectorAgent(Agent):
    name = "收集者"
    description = "循环抓取资料、抽取事实,直到凑齐足够的事实"

    def run(self, ctx: AgentContext) -> str:
        ctx.trace(f"▶ 子 Agent[{self.name}] 开始: {self.description}")
        loop = CollectorLoop(max_rounds=6)
        status = loop.run(ctx)
        facts = ctx.data.get("facts", [])
        ctx.data["collector_done"] = True  # 通知撰写者:收集已结束(无论成败)
        summary = f"共收集 {len(facts)} 条事实,循环 {loop.rounds_run} 轮,状态={status.value}"
        ctx.data.setdefault("reports", {})[self.name] = summary
        ctx.send("assistant", f"[{self.name}] 完成: {summary}")
        ctx.trace(f"◼ 子 Agent[{self.name}] 结束: {summary}")
        return "\n".join(f"- {f}" for f in facts)


# =========================================================================== #
# Agent B —— 初稿撰写者
# =========================================================================== #
class WriterLoop(AgentLoop):
    """目标驱动循环:等待事实齐备 → 写作 → 自评打分 → 未达标则修订。"""

    def __init__(self, max_rounds: int = 8):
        super().__init__("撰写循环", max_rounds)
        self.write_round = 0  # 仅统计真正写作的轮次(等待轮不计入)

    # ------------------------------------------------------------------ #
    # 规则模式(无 LLM 时)
    # ------------------------------------------------------------------ #
    @staticmethod
    def _keywords(fact: str) -> list[str]:
        """从一句事实中提取 2~4 字关键词,用于检查初稿是否引用了该事实。"""
        cleaned = re.sub(r"[，。、：:；;\"'《》()（）\s]", "", fact)
        return [cleaned[i : i + 2] for i in range(0, min(len(cleaned), 8), 2)]

    def _score(self, draft: str, facts: list[str]) -> tuple[int, list[str]]:
        score, notes = 0, []
        chars = len(re.sub(r"\s", "", draft))
        if chars >= 300:
            score += 40
        elif chars >= 150:
            score += 20
            notes.append("篇幅中等,再扩充一些更好")
        else:
            notes.append(f"篇幅不足({chars}字),建议扩到 300 字以上")

        paras = len([p for p in draft.strip().split("\n\n") if p.strip()])
        if paras >= 3:
            score += 30
        else:
            notes.append(f"段落仅 {paras} 段,建议至少 3 段")

        used = sum(1 for f in facts if any(kw in draft for kw in self._keywords(f)))
        if used >= 5:
            score += 30
        elif used >= 2:
            score += 15
            notes.append(f"仅引用了 {used}/{len(facts)} 条事实,建议多引用")
        else:
            notes.append("几乎没有引用收集到的事实,请补充")

        return score, notes

    def _compose(self, facts: list[str], topic: str) -> str:
        """首轮写作:只引用前 3 条事实(故意留短,触发后续修订)。"""
        title = f"关于「{topic}」的观察报告"
        body = "\n\n".join(
            [
                "## 概述\n" + facts[0] + "。",
                "## 要点\n" + "。".join(facts[1:3]) + "。",
            ]
        )
        return f"{title}\n\n{body}"

    def _revise(self, draft: str, facts: list[str], round_no: int) -> str:
        """修订轮:追加未被引用的新事实,或补一句总结性内容。"""
        extra = [f for f in facts if f not in draft][:2]
        addition = "。".join(extra) + "。" if extra else "此外,坚持固定议程与限时发言,能显著提升会议效率。"
        return draft + f"\n\n## 补充({round_no})\n{addition}"

    # ------------------------------------------------------------------ #
    # LLM 模式
    # ------------------------------------------------------------------ #
    def _compose_llm(self, ctx: AgentContext, facts: list[str], topic: str) -> str:
        system = "你是一名资深中文撰稿人,擅长把素材组织成结构清晰、语言通顺的文章。"
        user = (
            f"请根据以下事实,写一篇关于「{topic}」的观察报告。\n"
            f"要求:有标题;正文至少 3 个段落;尽量引用全部事实;直接输出正文,不要任何解释。\n\n"
            f"事实清单:\n" + "\n".join(f"- {f}" for f in facts)
        )
        return ctx.llm.chat(system, user).strip()

    def _score_llm(
        self, ctx: AgentContext, draft: str, facts: list[str]
    ) -> tuple[int, list[str]]:
        system = "你是严格的稿件评审专家,打分客观、宁严勿松。"
        user = (
            "请评审下面这篇稿件,按三个维度打分(满分 100):\n"
            "  篇幅充实度(0-40)、段落结构(0-30)、对给定事实的引用覆盖(0-30)。\n"
            "只输出两行,不要多余内容:\n"
            "得分: <0-100 的整数>\n"
            "改进意见: <一条最关键的改进建议>\n\n"
            f"待评审事实(用于核对引用):\n" + "\n".join(f"- {f}" for f in facts) + "\n\n"
            f"稿件:\n{draft}"
        )
        try:
            text = ctx.llm.chat(system, user)
        except Exception as e:
            ctx.trace(f"  [LLM 评分失败,按 0 分处理] {e}")
            return 0, ["LLM 评分失败,请人工检查"]
        m = re.search(r"得分[:：]\s*(\d{1,3})", text)
        score = int(m.group(1)) if m else 0
        m2 = re.search(r"改进意见[:：]\s*(.+)", text, re.S)
        notes = [m2.group(1).strip()] if m2 else ["无具体意见,请自查"]
        return min(score, 100), notes

    def _revise_llm(
        self, ctx: AgentContext, draft: str, facts: list[str], notes: list[str]
    ) -> str:
        system = "你是资深中文撰稿人,严格按照评审意见修订稿件。"
        user = (
            f"评审意见: {'; '.join(notes)}\n\n"
            f"请据此修订下面的初稿,可直接补充事实:\n"
            + "\n".join(f"- {f}" for f in facts)
            + "\n\n要求:直接输出修订后的完整正文,不要解释、不要输出意见。\n\n初稿:\n"
            + draft
        )
        return ctx.llm.chat(system, user).strip()

    # ------------------------------------------------------------------ #
    # 循环主体
    # ------------------------------------------------------------------ #
    def step(self, ctx: AgentContext) -> LoopStatus:
        facts = ctx.data.get("facts", [])
        topic = ctx.data.get("topic", "协作式团队晨会")
        # 前置依赖:等收集者凑齐事实(三个 loop 并行,共享数据区协作)。
        # WAITING 不消耗干活轮次,LLM 慢速收集时也能等到。
        if len(facts) < MIN_FACTS:
            if ctx.data.get("collector_done"):
                # 收集者已结束但事实不足:上游失败,不再干等,直接失败
                ctx.trace(
                    f"  ✗ 收集者已结束但事实不足({len(facts)}/{MIN_FACTS}),无法撰写"
                )
                return LoopStatus.EXHAUSTED
            if not getattr(self, "_wait_notified", False):
                ctx.trace(f"  等待收集者凑齐事实...({len(facts)}/{MIN_FACTS})")
                self._wait_notified = True
            return LoopStatus.WAITING

        self.write_round += 1
        if ctx.llm:
            if self.write_round == 1:
                new_draft = self._compose_llm(ctx, facts, topic)
            else:
                new_draft = self._revise_llm(
                    ctx, ctx.data.get("draft", ""), facts, ctx.data.get("last_notes", [])
                )
        else:
            if self.write_round == 1:
                new_draft = self._compose(facts, topic)
            else:
                new_draft = self._revise(ctx.data.get("draft", ""), facts, self.write_round)
        ctx.data["draft"] = new_draft

        if ctx.llm:
            score, notes = self._score_llm(ctx, new_draft, facts)
        else:
            score, notes = self._score(new_draft, facts)
        ctx.data["score"] = score
        ctx.data["last_notes"] = notes  # 供下一轮修订参考
        line = f"  第{self.write_round}轮写作: 成稿 {len(new_draft)} 字,自评 {score}/{SCORE_TARGET} 分"
        if notes:
            line += f" → 改进点: {'; '.join(notes[:2])}"
        ctx.trace(line)
        return LoopStatus.DONE if score >= SCORE_TARGET else LoopStatus.CONTINUE


class WriterAgent(Agent):
    name = "撰写者"
    description = "基于资料写初稿并自我评分,循环修订直到达标"

    def run(self, ctx: AgentContext) -> str:
        ctx.trace(f"▶ 子 Agent[{self.name}] 开始: {self.description}")
        loop = WriterLoop(max_rounds=8)
        status = loop.run(ctx)
        draft = ctx.data.get("draft", "")
        score = ctx.data.get("score", 0)
        summary = f"初稿 {len(draft)} 字,自评 {score} 分,循环 {loop.rounds_run} 轮(写作 {loop.write_round} 轮),状态={status.value}"
        ctx.data["writer_done"] = True  # 通知审校者:撰写流程已结束
        if not draft:
            ctx.data["writer_failed"] = True  # 未能产出稿件,审校者可快速失败
        ctx.data.setdefault("reports", {})[self.name] = summary
        ctx.send("assistant", f"[{self.name}] 完成: {summary}")
        ctx.trace(f"◼ 子 Agent[{self.name}] 结束: {summary}")
        return draft


# =========================================================================== #
# Agent C —— 质量审校者
# =========================================================================== #
class ReviewerLoop(AgentLoop):
    """目标驱动循环:轮询等待最终稿 → 审校 → 修正 → 再审校,直到检查通过。"""

    def __init__(self, max_rounds: int = 12):
        super().__init__("审校循环", max_rounds)
        self._prev_fixed: str | None = None  # 上一轮修正稿,用于判定收敛

    @staticmethod
    def _fix(text: str) -> str:
        """规则修正:英文句点→中文句号;去重复字;去全角空格。"""
        text = re.sub(r"(?<=[^\n。！？])\.[\s]?", "。", text)
        text = re.sub(r"([的了是在和与])\1", r"\1", text)
        text = text.replace("\u3000", "")
        return text

    def _review_llm(self, ctx: AgentContext, draft: str) -> str:
        """LLM 审校:无问题返回 "OK";有问题返回修正后的完整文稿。

        失败时返回原稿(不误报通过),错误留在 trace 中供排查。
        """
        system = "你是严谨的中文文字审校员,擅长发现错别字、标点、重复字和语病。"
        user = (
            "请审校下面的文稿。\n"
            "判断标准:只有存在错别字、标点错误、重复字或病句等明显问题时才需要修正;\n"
            "如果文稿质量已可接受(允许不影响理解的个别细节),只输出两个字: OK。\n"
            "如果需要修正,直接输出修正后的完整文稿(不要输出问题清单,不要解释)。\n\n"
            f"文稿:\n{draft}"
        )
        try:
            return ctx.llm.chat(system, user).strip()
        except Exception as e:
            ctx.trace(f"  [LLM 审校失败,保留原稿] {e}")
            return draft

    def step(self, ctx: AgentContext) -> LoopStatus:
        # 前置依赖:等撰写者产出非空最终稿。WAITING 不消耗干活轮次。
        if ctx.data.get("writer_failed"):
            ctx.trace("  ✗ 撰写者未能产出稿件,无法审校")
            return LoopStatus.EXHAUSTED
        if not ctx.data.get("writer_done") or not ctx.data.get("draft"):
            if not getattr(self, "_wait_notified", False):
                ctx.trace("  等待撰写者产出最终稿...")
                self._wait_notified = True
            return LoopStatus.WAITING

        draft = ctx.data.get("draft", "")
        if ctx.llm:
            result = self._review_llm(ctx, draft)
            if result == "OK":
                ctx.trace("  审校通过(LLM),无问题")
                return LoopStatus.DONE
            if result == draft or (
                self._prev_fixed is not None and result == self._prev_fixed
            ):
                # LLM 未做实质修改(输出与上轮相同):已收敛,视为通过
                ctx.trace("  审校通过(LLM 无实质修改,已收敛)")
                return LoopStatus.DONE
            self._prev_fixed = result
            ctx.data["draft"] = result  # LLM 修正稿回写共享数据区
            ctx.trace("  LLM 审校发现并修正了问题,进入再审校...")
            return LoopStatus.CONTINUE

        issues = ctx.tool("spelling_check", draft)
        if issues == "OK":
            ctx.trace("  审校通过,无问题")
            return LoopStatus.DONE

        fixed = self._fix(draft)
        ctx.data["draft"] = fixed  # 修正回写共享数据区
        ctx.trace(f"  发现并修正问题: {issues[:60]}...")
        return LoopStatus.CONTINUE


class ReviewerAgent(Agent):
    name = "审校者"
    description = "循环审校初稿并修正问题,直到质量检查通过"

    def run(self, ctx: AgentContext) -> str:
        ctx.trace(f"▶ 子 Agent[{self.name}] 开始: {self.description}")
        loop = ReviewerLoop(max_rounds=12)
        status = loop.run(ctx)
        final_text = ctx.data.get("draft", "")
        summary = f"审校完成,循环 {loop.rounds_run} 轮,状态={status.value}"
        ctx.data.setdefault("reports", {})[self.name] = summary
        ctx.send("assistant", f"[{self.name}] 完成: {summary}")
        ctx.trace(f"◼ 子 Agent[{self.name}] 结束: {summary}")
        return final_text
