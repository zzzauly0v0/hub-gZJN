"""子 Agent 可用的简单工具:文件读写、本地"资料抓取"、文本统计。

说明:演示环境无网络,资料"抓取"实现为读取本地 data/sources 目录,
行为上与真实 web fetch 对齐(输入 URL/主题,返回正文),便于将来
替换成真正的网络/搜索工具而不改动 Agent 代码。
"""

from __future__ import annotations

import os
import re
from pathlib import Path


def _sources_dir(workdir: str) -> Path:
    return Path(workdir) / "data" / "sources"


# --------------------------------------------------------------------------- #
# 文件工具
# --------------------------------------------------------------------------- #
def read_file(workdir: str, rel_path: str) -> str:
    """读取工作区内的文本文件。"""
    full = Path(workdir) / rel_path
    if not full.exists():
        return f"[错误] 文件不存在: {rel_path}"
    return full.read_text(encoding="utf-8")


def write_file(workdir: str, rel_path: str, content: str) -> str:
    """把文本写入工作区内的文件(自动创建父目录)。"""
    full = Path(workdir) / rel_path
    full.parent.mkdir(parents=True, exist_ok=True)
    full.write_text(content, encoding="utf-8")
    return f"[已写入] {rel_path} ({len(content)} 字符)"


# --------------------------------------------------------------------------- #
# 模拟资料抓取:读取 data/sources/*.txt
# --------------------------------------------------------------------------- #
def fetch_article(workdir: str, topic: str = "", index: int | None = None) -> str:
    """模拟抓取一篇资料:按文件名关键词匹配;index 指定抓第几篇;默认第一篇。"""
    src = _sources_dir(workdir)
    if not src.exists():
        return "[错误] 资料目录不存在"
    files = sorted(src.glob("*.txt"))
    if not files:
        return "[错误] 资料目录为空"
    if topic:
        for f in files:
            if topic.lower() in f.stem.lower():
                return f"[资料: {f.name}]\n" + f.read_text(encoding="utf-8")
    if index is not None:
        if not (0 <= index < len(files)):
            return "[错误] 资料已全部抓完"
        f = files[index]
        return f"[资料: {f.name}]\n" + f.read_text(encoding="utf-8")
    return f"[资料: {files[0].name}]\n" + files[0].read_text(encoding="utf-8")


def list_sources(workdir: str) -> str:
    """列出资料库中的可用来源(模拟搜索引擎结果页)。"""
    src = _sources_dir(workdir)
    if not src.exists():
        return "[错误] 资料目录不存在"
    files = sorted(src.glob("*.txt"))
    if not files:
        return "[错误] 资料目录为空"
    lines = [f"共 {len(files)} 条来源:"]
    for i, f in enumerate(files, 1):
        head = f.read_text(encoding="utf-8").strip().splitlines()[0] if f.stat().st_size else ""
        lines.append(f"  {i}. {f.stem} —— {head[:40]}")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# 文本统计与质量检查
# --------------------------------------------------------------------------- #
def text_stats(workdir: str, text: str) -> str:
    """统计文本:总字数、句数、段落数。"""
    chars = len(re.sub(r"\s", "", text))
    sentences = len([s for s in re.split(r"[。！？.!?]", text) if s.strip()])
    paragraphs = len([p for p in text.strip().split("\n\n") if p.strip()])
    return f"字数(不含空白): {chars} | 句子: {sentences} | 段落: {paragraphs}"


def spelling_check(workdir: str, text: str) -> str:
    """极简"拼写/规范"检查:模拟审校 Agent 的规则工具。

    检查项:
      1. 句子以中文句号结尾(英文句点视为不规范);
      2. 出现"的的"、"了了"等重复字;
      3. 出现全角空格。
    返回问题清单;无问题返回 "OK"。
    """
    issues = []
    # 1) 英文句点结尾
    for i, s in enumerate(re.split(r"(?<=[。！？])|\n", text), 1):
        s = s.strip()
        if s and s.endswith(".") and not s.endswith("..."):
            issues.append(f"第{i}段以英文句点结尾,应为中文句号")
    # 2) 重复字
    for dup in re.findall(r"(.)\1", text):
        if dup in "的了是在和与":
            issues.append(f"出现重复字「{dup}{dup}」")
            break
    # 3) 全角空格
    if "\u3000" in text:
        issues.append("包含全角空格")
    return "OK" if not issues else ("; ".join(issues))


def register(workdir: str) -> dict:
    """注册全部工具,返回 {工具名: callable}。"""
    return {
        "read_file": lambda rel: read_file(workdir, rel),
        "write_file": lambda rel, content: write_file(workdir, rel, content),
        "fetch_article": lambda topic="", index=None: fetch_article(workdir, topic, index),
        "list_sources": lambda: list_sources(workdir),
        "text_stats": lambda text: text_stats(workdir, text),
        "spelling_check": lambda text: spelling_check(workdir, text),
    }
