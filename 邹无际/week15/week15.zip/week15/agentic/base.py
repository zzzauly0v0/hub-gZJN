"""核心抽象:消息、上下文、目标驱动循环(AgentLoop)与 Agent 基类。

设计要点
--------
- AgentLoop 是"循环"的最小抽象:每一轮调用 step() 返回一个状态,
  由循环内部判断"继续还是结束",从而形成 目标驱动(goal-driven) 的循环,
  而不是固定次数的 for 循环。
- AgentContext 是子 Agent 之间共享的工作台:消息历史、可用工具、
  共享数据区(data)、以及供主 Agent 汇总用的执行轨迹(trace)。
- Agent 是具备名字与职责描述的执行单元;主 Agent 也是 Agent。
"""

from __future__ import annotations

import threading
import time
from dataclasses import dataclass, field
from enum import Enum
from typing import Any, Callable, Optional


# --------------------------------------------------------------------------- #
# 消息
# --------------------------------------------------------------------------- #
@dataclass
class Message:
    """Agent 之间传递的消息。role: system / user / assistant / tool"""

    role: str
    content: str
    meta: dict = field(default_factory=dict)

    def __str__(self) -> str:  # 便于日志打印
        return f"[{self.role}] {self.content}"


# --------------------------------------------------------------------------- #
# 循环状态
# --------------------------------------------------------------------------- #
class LoopStatus(str, Enum):
    CONTINUE = "continue"  # 继续下一轮(消耗轮次)
    WAITING = "waiting"    # 前置依赖未就绪,等待重试(不消耗干活轮次)
    DONE = "done"          # 目标达成,正常结束
    EXHAUSTED = "exhausted"  # 达到轮次/等待上限,资源耗尽,被迫结束


# --------------------------------------------------------------------------- #
# 循环抽象
# --------------------------------------------------------------------------- #
class AgentLoop:
    """目标驱动循环基类。

    子类只需实现 step():执行一轮动作,返回 LoopStatus。
    run() 负责驱动循环:
    - WAITING 轮不消耗干活轮次(适配 LLM 慢速场景,避免等待时耗尽轮次);
    - 干活轮(CONTINUE/DONE/EXHAUSTED)消耗 max_rounds;
    - 等待总次数超过 max_wait_rounds 也强制结束。
    """

    def __init__(
        self,
        name: str,
        max_rounds: int = 5,
        pause: float = 0.05,
        max_wait_rounds: int = 120,
        wait_pause: float = 1.0,
    ):
        self.name = name
        self.max_rounds = max_rounds
        self.pause = pause  # 干活轮之间的停顿
        self.max_wait_rounds = max_wait_rounds  # 等待重试上限
        self.wait_pause = wait_pause  # 等待轮之间的停顿
        self.rounds_run = 0
        self.wait_rounds = 0

    def step(self, ctx: "AgentContext") -> LoopStatus:
        raise NotImplementedError(f"{type(self).__name__} 必须实现 step()")

    def run(self, ctx: "AgentContext") -> LoopStatus:
        """驱动循环:WAITING 轮重试等待;干活轮直到 DONE / EXHAUSTED。"""
        self.rounds_run = 0
        self.wait_rounds = 0
        while self.rounds_run < self.max_rounds:
            status = self.step(ctx)
            if status == LoopStatus.WAITING:
                self.wait_rounds += 1
                if self.wait_rounds >= self.max_wait_rounds:
                    ctx.trace(f"  ⚠ 等待前置依赖超时({self.max_wait_rounds} 次),强制结束")
                    return LoopStatus.EXHAUSTED
                time.sleep(self.wait_pause)
                continue
            self.rounds_run += 1
            ctx.trace(f"  ↳ 第{self.rounds_run}轮结束: {status.value}")
            if status != LoopStatus.CONTINUE:
                break
            time.sleep(self.pause)
        else:
            ctx.trace(f"  ⚠ 达到最大轮次({self.max_rounds}),强制结束")
            return LoopStatus.EXHAUSTED
        return status


# --------------------------------------------------------------------------- #
# Agent 上下文(共享工作台)
# --------------------------------------------------------------------------- #
class AgentContext:
    """子 Agent 共享的工作台,由主 Agent 创建并注入。

    - messages: 整个协作过程的对话消息
    - data:     共享数据区(子 Agent 把产出写进来,主 Agent 汇总时读取)
    - trace:    执行轨迹,记录每个循环每一轮的动作,供最终汇报展示
    - tools:    可用的工具集合 {name: callable}
    """

    def __init__(
        self,
        workdir: str,
        tools: Optional[dict[str, Callable]] = None,
        llm: Optional["object"] = None,
    ):
        self.workdir = workdir
        self.tools: dict[str, Callable] = tools or {}
        self.llm = llm  # 为 None 时子 Agent 走规则模式;否则走 LLM 分支
        self.messages: list[Message] = []
        self.data: dict[str, Any] = {}
        self._trace: list[str] = []
        self._lock = threading.Lock()  # 并行写日志时保护输出顺序

    # -- 消息 --------------------------------------------------------------- #
    def send(self, role: str, content: str, **meta: Any) -> None:
        with self._lock:
            self.messages.append(Message(role, content, meta))

    # -- 工具 --------------------------------------------------------------- #
    def tool(self, name: str, *args: Any, **kwargs: Any) -> Any:
        """调用一个已注册的工具;工具不存在时给出明确报错。"""
        if name not in self.tools:
            raise KeyError(f"工具 '{name}' 未注册,可用: {sorted(self.tools)}")
        return self.tools[name](*args, **kwargs)

    # -- 轨迹与日志 --------------------------------------------------------- #
    def trace(self, line: str) -> None:
        with self._lock:
            self._trace.append(line)

    @property
    def trace_log(self) -> list[str]:
        return list(self._trace)


# --------------------------------------------------------------------------- #
# Agent 基类
# --------------------------------------------------------------------------- #
class Agent:
    """一切 Agent(含主 Agent)的基类。

    子类需要定义 name / description,并实现 run()。
    run() 返回该 Agent 的最终产出(文本)。
    """

    name: str = "agent"
    description: str = ""

    def run(self, ctx: AgentContext) -> str:
        raise NotImplementedError(f"{type(self).__name__} 必须实现 run()")
