"""多 Agent 编排系统:主 Agent 下发子 Agent,子 Agent 各自运行目标驱动循环,结果汇总。"""

__version__ = "0.1.0"
